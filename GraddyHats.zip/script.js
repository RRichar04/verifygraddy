// Selecciona el modal y el contenido de la imagen
const modal = document.getElementById("imageModal");
const imgExpanded = document.getElementById("imgExpanded");
const closeBtn = document.querySelector(".close");

// Agrega evento a cada imagen para que abra el modal al hacer clic
document.querySelectorAll(".expand-img").forEach(img => {
    img.addEventListener("click", function () {
        modal.style.display = "flex";
        imgExpanded.src = this.src;
    });
});

// Cerrar el modal al hacer clic en la "X"
closeBtn.addEventListener("click", function () {
    modal.style.display = "none";
});

// Cerrar el modal al hacer clic fuera de la imagen
modal.addEventListener("click", function (e) {
    if (e.target === modal) {
        modal.style.display = "none";
    }
});

